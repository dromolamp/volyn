<?php
return array(
    'order'=>'1',
    'rules'=>array(
        "volyn/<controller>/<action>"=>"volyn/<controller>/<action>",
    )
);