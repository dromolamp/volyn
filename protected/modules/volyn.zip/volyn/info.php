<?php
return array(
    'title'=>'Volyn',
    'description'=>'Volyn',
    'version'=>'1.0',
    'author'=>array(
        'url'=>'mvi.pp.ua',
        'name'=>'vitalii',
        'email'=>'dromolamp@ukr.net',
    ),
    'admin_controller'=>'/admin/article.index',
);